#ifndef _INPUT_H_INCLUDED_
#define _INPUT_H_INCLUDED_

void input(const int);

#endif /* _INPUT_H_INCLUDED_ */
