#ifndef _OUTPUT_H_INCLUDED_
#define _OUTPUT_H_INCLUDED_

void output(const int);

#endif /* _OUTPUT_H_INCLUDED_ */
