#ifndef _DRIVER_SPECS_H_INCLUDED_
#define _DRIVER_SPECS_H_INCLUDED_

#include <linux/ioctl.h>

#define DEVICE_NAME "stopwatch"
#define DEVICE_MAJOR_NUMBER 242

#endif /* _DRIVER_SPECS_H_INCLUDED_ */
